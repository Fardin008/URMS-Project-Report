<?php
session_start();
require 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name']; // Use first_name instead of username
    $password = $_POST['password'];

    // Query to fetch user based on first_name
    $sql = "SELECT * FROM users WHERE first_name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $first_name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if ($password === $user['password']) { // Directly compare the plain text password
            $_SESSION['id'] = $user['id']; // Store the user's ID in the session
            $_SESSION['role'] = $user['role'];

            // Redirect based on role
            if ($user['role'] == 'admin') {
                header("Location: admin/admin_dashboard.php");
            } elseif ($user['role'] == 'faculty') {
                header("Location: teacher/teacher_dashboard.php");
            } elseif ($user['role'] == 'student') {
                header("Location: student/student_dashboard.php");
            }
            exit();
        } else {
            echo "<div class='alert alert-danger text-center'>Invalid password!</div>";
        }
    } else {
        echo "<div class='alert alert-danger text-center'>Invalid first name!</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - URMS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Login to University Resource Management System</h2>
        <div class="row justify-content-center">
            <div class="col-md-4">
                <form action="login.php" method="POST">
                    <div class="form-group">
                        <label for="first_name">First Name:</label> <!-- Updated label -->
                        <input type="text" class="form-control" id="first_name" name="first_name" required> <!-- Updated input -->
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
