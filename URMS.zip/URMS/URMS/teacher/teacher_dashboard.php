<?php
session_start();
if ($_SESSION['role'] !== 'faculty') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (!isset($_SESSION['id'])) {
    die("Error: User ID not found in session.");
}

$faculty_id = $_SESSION['id']; // Use 'id' from the session

// Fetch courses assigned to the teacher
$courses_sql = "
    SELECT courses.course_id, courses.course_name, courses.credits, courses.course_fee 
    FROM courses 
    WHERE courses.faculty_id = ?
";
$stmt = $conn->prepare($courses_sql);
$stmt->bind_param("i", $faculty_id);
$stmt->execute();
$courses_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?> <!-- Include the navigation bar -->
    <div class="container mt-5">
        <h2 class="text-center">Teacher Dashboard</h2>
        <p class="text-center">Welcome to your dashboard. Use the navigation bar above to manage your courses and students.</p>
       
       
    </div>
</body>
</html>
