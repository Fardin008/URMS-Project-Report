<?php
session_start();
if ($_SESSION['role'] !== 'faculty') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (!isset($_SESSION['id'])) {
    die("Error: User ID not found in session.");
}

// Get the logged-in user's ID from the session
$user_id = $_SESSION['id'];

// Fetch the faculty_id for the logged-in user
$faculty_sql = "SELECT faculty_id FROM faculty WHERE id = ?";
$stmt = $conn->prepare($faculty_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$faculty_result = $stmt->get_result();

if ($faculty_result->num_rows === 0) {
    die("Error: Faculty ID not found for the logged-in user.");
}

$faculty_row = $faculty_result->fetch_assoc();
$faculty_id = $faculty_row['faculty_id'];

// Fetch courses assigned to the faculty
$courses_sql = "
    SELECT courses.course_id, courses.course_name, courses.credits
    FROM courses 
    WHERE courses.faculty_id = ?
";
$stmt = $conn->prepare($courses_sql);
$stmt->bind_param("i", $faculty_id);
$stmt->execute();
$courses_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assigned Courses</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Assigned Courses</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Credits</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $courses_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['course_id']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                    <td><?php echo $row['credits']; ?></td>
                    
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>