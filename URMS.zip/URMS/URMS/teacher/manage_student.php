<?php
session_start();
if ($_SESSION['role'] !== 'faculty') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (!isset($_SESSION['id']) || !isset($_SESSION['role'])) {
    die("Error: User information not found in session.");
}

$user_id = $_SESSION['id']; // Use the user ID directly from the session

// Fetch the faculty_id from the `faculty` table
$faculty_sql = "SELECT faculty_id FROM faculty WHERE id = ?"; // Updated column name
$stmt = $conn->prepare($faculty_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$faculty_result = $stmt->get_result();

if ($faculty_result->num_rows === 0) {
    die("Error: Faculty ID not found for the logged-in user.");
}

$faculty_row = $faculty_result->fetch_assoc();
$faculty_id = $faculty_row['faculty_id'];

// Fetch students for the teacher's assigned courses
$students_sql = "
    SELECT students.student_id, 
           CONCAT(users.first_name, ' ', users.last_name) AS name, 
           student_courses.course_id, 
           courses.course_name
    FROM students 
    JOIN users ON students.id = users.id 
    JOIN student_courses ON students.student_id = student_courses.student_id
    JOIN courses ON student_courses.course_id = courses.course_id
    WHERE student_courses.course_id IN (
        SELECT course_id FROM courses WHERE faculty_id = ?
    )
";
$stmt = $conn->prepare($students_sql);
$stmt->bind_param("i", $faculty_id);

if (!$stmt->execute()) {
    die("Error executing query: " . $stmt->error);
}

$students_result = $stmt->get_result();

if ($students_result->num_rows === 0) {
    die("No students found for your assigned courses.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Students</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Manage Students</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Course Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($students_result->num_rows === 0) { ?>
                    <tr>
                        <td colspan="4">No students found for your assigned courses.</td>
                    </tr>
                <?php } else { ?>
                    <?php while ($row = $students_result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['student_id']; ?></td>
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['course_name']; ?></td> <!-- Display course name -->
                        <td><a href="upload_result.php?student_id=<?php echo $row['student_id']; ?>&course_id=<?php echo $row['course_id']; ?>" class="btn btn-primary">Upload Results</a></td>
                    </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>