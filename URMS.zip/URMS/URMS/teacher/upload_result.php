<?php
session_start();
if ($_SESSION['role'] !== 'faculty') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (!isset($_GET['student_id']) || !isset($_GET['course_id'])) {
    die("Error: Missing student or course ID.");
}

$student_id = $_GET['student_id'];
$course_id = $_GET['course_id'];

// Fetch the faculty_id from the faculty table
$faculty_sql = "SELECT faculty_id FROM faculty WHERE id = ?";
$stmt = $conn->prepare($faculty_sql);
$stmt->bind_param("i", $_SESSION['id']);
$stmt->execute();
$faculty_result = $stmt->get_result();

if ($faculty_result->num_rows === 0) {
    die("Error: Faculty ID not found for the logged-in user.");
}

$faculty_row = $faculty_result->fetch_assoc();
$faculty_id = $faculty_row['faculty_id'];



// Verify that the student belongs to the teacher's course
$verify_sql = "
    SELECT 1 
    FROM student_courses 
    JOIN courses ON student_courses.course_id = courses.course_id
    WHERE student_courses.student_id = ? 
      AND student_courses.course_id = ? 
      AND courses.faculty_id = ?
";
$stmt = $conn->prepare($verify_sql);
$stmt->bind_param("iii", $student_id, $course_id, $faculty_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Error: Unauthorized access.");
}

// Handle grade upload logic here
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $grade = $_POST['grade'];
    $semester = $_POST['semester'];

    // Insert or update the grade in the results table
    $insert_sql = "
        INSERT INTO results (student_id, course_id, grade, semester) 
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE grade = VALUES(grade), semester = VALUES(semester)
    ";
    $stmt = $conn->prepare($insert_sql);
    $stmt->bind_param("iiss", $student_id, $course_id, $grade, $semester);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success text-center'>Grade uploaded successfully!</div>";
    } else {
        echo "<div class='alert alert-danger text-center'>Error uploading grade. Please try again.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Result</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?> <!-- Include the navigation bar -->
    <div class="container mt-5">
        <h2 class="text-center">Upload Result</h2>
        <form method="POST">
            <div class="form-group">
                <label for="grade">Grade</label>
                <input type="text" name="grade" id="grade" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="semester">Semester</label>
                <input type="text" name="semester" id="semester" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
            <a href="manage_student.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
