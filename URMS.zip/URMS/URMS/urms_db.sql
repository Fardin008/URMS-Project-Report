-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2025 at 10:16 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `credits` int(11) NOT NULL,
  `course_fee` decimal(10,2) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `credits`, `course_fee`, `faculty_id`) VALUES
(1, 'Introduction to Programming', 1, 5000.00, 1),
(2, 'Structured Programming', 3, 15000.00, 1),
(3, 'Structured Programming LAB', 1, 5000.00, 1),
(4, 'Discrete Mathematics', 3, 15000.00, 1),
(5, 'Data Structures', 3, 15000.00, 2),
(6, 'Data Structures LAB', 1, 5000.00, 2),
(7, 'Digital Logic Design', 3, 15000.00, 2),
(8, 'Digital Logic Design LAB', 1, 5000.00, 2),
(9, 'Object Oriented Programming', 3, 15000.00, 2),
(10, 'Object Oriented Programming LAB', 1, 5000.00, 2),
(11, 'Algorithms', 3, 15000.00, 3),
(12, 'Algorithms LAB', 1, 5000.00, 3),
(13, 'Computer Organization and Architecture', 3, 15000.00, 3),
(14, 'Database Management System', 3, 15000.00, 4),
(15, 'Database Management System LAB', 1, 5000.00, 4),
(16, 'Automata and Theory of Computation', 3, 15000.00, 4),
(17, 'Operating Systems', 3, 15000.00, 4),
(18, 'Operating Systems LAB', 1, 5000.00, 4),
(19, 'Microprocessor and Microcontroller', 3, 15000.00, 5),
(20, 'Microprocessor and Microcontroller LAB', 1, 5000.00, 5),
(21, 'Academic English I (GED 1)', 3, 15000.00, 8),
(22, 'Bangla Bhasha (GED 2)', 3, 15000.00, 9),
(23, 'Study Skills', 0, 0.00, 9),
(24, 'Emergence of Independent Bangladesh (GED 3)', 3, 15000.00, 10),
(25, 'Academic English II (GED 4)', 3, 15000.00, 8),
(26, 'Healthy Life Skills', 0, 0.00, 10),
(27, 'Professional Ethics (GED 5)', 3, 15000.00, 8),
(28, 'GED Elective 1 (GED 6 from Tier 1)', 3, 15000.00, 10),
(29, 'Environment and Sustainability (GED 7 from Tier 2)', 3, 15000.00, 9),
(30, 'Industrial Management (GED 8 from Tier 3)', 3, 15000.00, 9);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(11) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `id`, `department`) VALUES
(1, 13, 'Computer Science and Engineering'),
(2, 14, 'Computer Science and Engineering'),
(3, 15, 'Computer Science and Engineering'),
(4, 16, 'Computer Science and Engineering'),
(5, 17, 'Computer Science and Engineering'),
(6, 18, 'Computer Science and Engineering'),
(7, 19, 'Computer Science and Engineering'),
(8, 20, 'General Education (GED)'),
(9, 21, 'English Literature'),
(10, 22, 'Environmental Studies');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_method` enum('bank','cash','online') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `student_id`, `course_id`, `amount`, `payment_date`, `payment_method`) VALUES
(1, 1, 1, 5000.00, '2023-01-15', 'bank'),
(2, 1, 2, 2000.00, '2023-01-15', 'cash'),
(3, 1, 3, 7000.00, '2023-01-15', 'online'),
(4, 1, 4, 13000.00, '2023-01-15', 'bank'),
(5, 1, 5, 1300.00, '2023-01-15', 'cash'),
(6, 1, 6, 4000.00, '2023-01-15', 'bank'),
(7, 1, 7, 5000.00, '2023-01-15', 'online'),
(8, 2, 3, 7000.00, '2023-02-05', 'cash'),
(9, 2, 5, 1300.00, '2023-02-05', 'bank'),
(10, 2, 8, 4000.00, '2023-02-05', 'online'),
(11, 2, 9, 1400.00, '2023-02-05', 'bank'),
(12, 2, 10, 700.00, '2023-02-05', 'online'),
(13, 2, 13, 5000.00, '2023-02-05', 'cash'),
(14, 3, 1, 5000.00, '2023-03-07', 'bank'),
(15, 3, 6, 4000.00, '2023-03-07', 'online'),
(16, 3, 8, 4000.00, '2023-03-07', 'cash'),
(17, 3, 10, 4000.00, '2023-03-07', 'online'),
(18, 3, 11, 1300.00, '2023-03-07', 'bank'),
(19, 3, 12, 6000.00, '2023-03-07', 'cash'),
(20, 4, 2, 2000.00, '2023-04-05', 'bank'),
(21, 4, 5, 1300.00, '2023-04-05', 'online'),
(22, 4, 7, 7000.00, '2023-04-05', 'bank'),
(23, 4, 8, 3000.00, '2023-04-05', 'cash'),
(24, 4, 9, 7000.00, '2023-04-05', 'online'),
(25, 4, 10, 2000.00, '2023-04-05', 'bank'),
(26, 5, 4, 5000.00, '2023-05-10', 'online'),
(27, 5, 6, 6000.00, '2023-05-10', 'cash'),
(28, 5, 9, 1400.00, '2023-05-10', 'bank'),
(29, 5, 11, 5000.00, '2023-05-10', 'online'),
(30, 5, 14, 5000.00, '2023-05-10', 'cash'),
(31, 6, 2, 5000.00, '2023-06-12', 'bank');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `result_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `grade` varchar(2) DEFAULT NULL,
  `semester` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`result_id`, `student_id`, `course_id`, `grade`, `semester`) VALUES
(1, 1, 1, 'A', 'Spring 2023'),
(2, 1, 2, 'B+', 'Spring 2023'),
(3, 1, 3, 'A-', 'Spring 2023'),
(4, 1, 4, 'A', 'Spring 2023'),
(5, 1, 5, 'B', 'Spring 2023'),
(6, 1, 6, 'A+', 'Spring 2023'),
(7, 1, 7, 'B+', 'Spring 2023'),
(8, 2, 3, 'A-', 'Spring 2023'),
(9, 2, 5, 'B+', 'Spring 2023'),
(10, 2, 8, 'A', 'Spring 2023'),
(11, 2, 9, 'A-', 'Spring 2023'),
(12, 2, 10, 'B', 'Spring 2023'),
(13, 2, 13, 'A', 'Spring 2023'),
(14, 3, 1, 'A', 'Spring 2023'),
(15, 3, 6, 'B+', 'Spring 2023'),
(16, 3, 8, 'A-', 'Spring 2023'),
(17, 3, 10, 'A', 'Spring 2023'),
(18, 3, 11, 'B', 'Spring 2023'),
(19, 3, 12, 'A+', 'Spring 2023'),
(20, 4, 2, 'B+', 'Spring 2023'),
(21, 4, 5, 'A', 'Spring 2023'),
(22, 4, 7, 'B+', 'Spring 2023'),
(23, 4, 8, 'A-', 'Spring 2023'),
(24, 4, 9, 'A', 'Spring 2023'),
(25, 4, 10, 'B+', 'Spring 2023'),
(26, 5, 4, 'B', 'Spring 2023'),
(27, 5, 6, 'A-', 'Spring 2023'),
(28, 5, 9, 'A', 'Spring 2023'),
(29, 5, 11, 'A+', 'Spring 2023'),
(30, 5, 14, 'A', 'Spring 2023'),
(31, 6, 2, 'A+', 'Spring 2023'),
(32, 1, 1, 'A+', 'Summer 2024');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `graduation_year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `id`, `graduation_year`) VALUES
(1, 3, 2023),
(2, 4, 2024),
(3, 5, 2023),
(4, 6, 2025),
(5, 7, 2023),
(6, 8, 2024),
(7, 9, 2025),
(8, 10, 2023),
(9, 11, 2024),
(10, 12, 2025);

-- --------------------------------------------------------

--
-- Table structure for table `student_courses`
--

CREATE TABLE `student_courses` (
  `student_id` int(11) NOT NULL,
  `id` int(11) DEFAULT NULL,
  `course_id` int(11) NOT NULL,
  `enrollment_date` date DEFAULT NULL,
  `progress` enum('in process','complete','drop') DEFAULT 'in process',
  `status` enum('registered','enrolled') DEFAULT 'registered'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_courses`
--

INSERT INTO `student_courses` (`student_id`, `id`, `course_id`, `enrollment_date`, `progress`, `status`) VALUES
(1, 3, 1, '2023-01-10', 'in process', 'registered'),
(1, 3, 2, '2023-01-10', 'in process', 'registered'),
(1, 3, 3, '2023-01-10', 'in process', 'registered'),
(1, 3, 4, '2023-01-10', 'in process', 'registered'),
(1, 3, 5, '2023-01-10', 'complete', 'registered'),
(1, 3, 6, '2023-01-10', 'in process', 'registered'),
(1, 3, 7, '2023-01-10', 'in process', 'registered'),
(2, 4, 3, '2023-02-01', 'complete', 'registered'),
(2, 4, 5, '2023-02-01', 'in process', 'registered'),
(2, 4, 8, '2023-02-01', 'in process', 'registered'),
(2, 4, 9, '2023-02-01', 'in process', 'registered'),
(2, 4, 10, '2023-02-01', 'complete', 'registered'),
(2, 4, 13, '2023-02-01', 'in process', 'registered'),
(3, 5, 1, '2023-03-05', 'in process', 'registered'),
(3, 5, 6, '2023-03-05', 'complete', 'registered'),
(3, 5, 8, '2023-03-05', 'in process', 'registered'),
(3, 5, 10, '2023-03-05', 'complete', 'registered'),
(3, 5, 11, '2023-03-05', 'in process', 'registered'),
(3, 5, 12, '2023-03-05', 'in process', 'registered'),
(4, 6, 2, '2023-04-15', 'in process', 'registered'),
(4, 6, 5, '2023-04-15', 'complete', 'registered'),
(4, 6, 7, '2023-04-15', 'in process', 'registered'),
(4, 6, 8, '2023-04-15', 'in process', 'registered'),
(4, 6, 9, '2023-04-15', 'complete', 'registered'),
(4, 6, 10, '2023-04-15', 'in process', 'registered'),
(5, 7, 4, '2023-05-10', 'in process', 'registered'),
(5, 7, 6, '2023-05-10', 'in process', 'registered'),
(5, 7, 9, '2023-05-10', 'complete', 'registered'),
(5, 7, 11, '2023-05-10', 'complete', 'registered'),
(5, 7, 14, '2023-05-10', 'in process', 'registered'),
(6, 8, 2, '2023-06-12', 'in process', 'registered'),
(6, 8, 5, '2023-06-12', 'in process', 'registered'),
(6, 8, 7, '2023-06-12', 'in process', 'registered'),
(6, 8, 8, '2023-06-12', 'in process', 'registered'),
(6, 8, 10, '2023-06-12', 'complete', 'registered');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','student','faculty') NOT NULL,
  `email` varchar(255) NOT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `mobile_no` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `password`, `role`, `email`, `blood_group`, `permanent_address`, `mobile_no`) VALUES
(1, 'Rahim', 'Uddin', 'adminpassword1', 'admin', 'rahim.uddin@bdmail.com', 'A+', 'Dhaka, Bangladesh', '01710000001'),
(2, 'Karim', 'Chowdhury', 'adminpassword2', 'admin', 'karim.chowdhury@bdmail.com', 'B+', 'Chittagong, Bangladesh', '01710000002'),
(3, 'Shakil', 'Hossain', 'studentpassword1', 'student', 'shakil.hossain@bdmail.com', 'O+', 'Sylhet, Bangladesh', '01710000003'),
(4, 'Mina', 'Begum', 'studentpassword2', 'student', 'mina.begum@bdmail.com', 'A-', 'Rajshahi, Bangladesh', '01710000004'),
(5, 'Tariq', 'Rahman', 'studentpassword3', 'student', 'tariq.rahman@bdmail.com', 'AB+', 'Khulna, Bangladesh', '01710000005'),
(6, 'Sultana', 'Nazneen', 'studentpassword4', 'student', 'sultana.nazneen@bdmail.com', 'B-', 'Barisal, Bangladesh', '01710000006'),
(7, 'Jahangir', 'Alam', 'studentpassword5', 'student', 'jahangir.alam@bdmail.com', 'O-', 'Mymensingh, Bangladesh', '01710000007'),
(8, 'Samiya', 'Ahmed', 'studentpassword6', 'student', 'samiya.ahmed@bdmail.com', 'AB-', 'Narsingdi, Bangladesh', '01710000008'),
(9, 'Rohit', 'Biswas', 'studentpassword7', 'student', 'rohit.biswas@bdmail.com', 'A+', 'Comilla, Bangladesh', '01710000009'),
(10, 'Nazia', 'Sultana', 'studentpassword8', 'student', 'nazia.sultana@bdmail.com', 'B+', 'Rajbari, Bangladesh', '01710000010'),
(11, 'Rafiqul', 'Islam', 'studentpassword9', 'student', 'rafiqul.islam@bdmail.com', 'O+', 'Jessore, Bangladesh', '01710000011'),
(12, 'Mojibur', 'Rahman', 'studentpassword10', 'student', 'mojibur.rahman@bdmail.com', 'A-', 'Tangail, Bangladesh', '01710000012'),
(13, 'Dr. Alamgir', 'Hossain', 'facultypassword1', 'faculty', 'alamgir.hossain@bdmail.com', 'O+', 'Dhaka, Bangladesh', '01710000013'),
(14, 'Dr. Nabila', 'Ahmed', 'facultypassword2', 'faculty', 'nabila.ahmed@bdmail.com', 'A-', 'Chittagong, Bangladesh', '01710000014'),
(15, 'Prof. Asad', 'Rahman', 'facultypassword3', 'faculty', 'asad.rahman@bdmail.com', 'B+', 'Rajshahi, Bangladesh', '01710000015'),
(16, 'Dr. Rubina', 'Chowdhury', 'facultypassword4', 'faculty', 'rubina.chowdhury@bdmail.com', 'AB+', 'Khulna, Bangladesh', '01710000016'),
(17, 'Prof. Jahir', 'Uddin', 'facultypassword5', 'faculty', 'jahir.uddin@bdmail.com', 'O-', 'Barisal, Bangladesh', '01710000017'),
(18, 'Dr. Shafiq', 'Siddique', 'facultypassword6', 'faculty', 'shafiq.siddique@bdmail.com', 'B-', 'Mymensingh, Bangladesh', '01710000018'),
(19, 'Prof. Meher', 'Sultana', 'facultypassword7', 'faculty', 'meher.sultana@bdmail.com', 'AB-', 'Narsingdi, Bangladesh', '01710000019'),
(20, 'Dr. Farhana', 'Islam', 'facultypassword8', 'faculty', 'farhana.islam@bdmail.com', 'A+', 'Comilla, Bangladesh', '01710000020'),
(21, 'Prof. Mustafiz', 'Rahman', 'facultypassword9', 'faculty', 'mustafiz.rahman@bdmail.com', 'B+', 'Rajbari, Bangladesh', '01710000021'),
(22, 'Dr. Mizan', 'Hossain', 'facultypassword10', 'faculty', 'mizan.hossain@bdmail.com', 'O+', 'Jessore, Bangladesh', '01710000022');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `faculty_id` (`faculty_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`),
  ADD KEY `user_id` (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `user_id` (`id`);

--
-- Indexes for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD PRIMARY KEY (`student_id`,`course_id`),
  ADD KEY `user_id` (`id`),
  ADD KEY `course_id` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `results`
--
ALTER TABLE `results`
  ADD CONSTRAINT `results_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `results_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);

--
-- Constraints for table `student_courses`
--
ALTER TABLE `student_courses`
  ADD CONSTRAINT `student_courses_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `student_courses_ibfk_2` FOREIGN KEY (`id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `student_courses_ibfk_3` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
