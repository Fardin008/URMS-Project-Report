<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

$user_id = $_SESSION['id']; // Use the logged-in user's ID from the session

// Fetch student details
$student_sql = "
    SELECT students.student_id, 
           CONCAT(users.first_name, ' ', users.last_name) AS name
    FROM students 
    JOIN users ON students.id = users.id 
    WHERE students.id = ?
";
$stmt = $conn->prepare($student_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student_result = $stmt->get_result();
$student = $student_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Welcome, <?php echo htmlspecialchars($student['name']); ?></h2>
        <!-- Graduation year removed -->
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
