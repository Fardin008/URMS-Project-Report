<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

$user_id = $_SESSION['id']; // Use the logged-in user's ID from the session

// Fetch the student's ID from the `students` table
$student_sql = "SELECT student_id FROM students WHERE id = ?";
$stmt = $conn->prepare($student_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student_result = $stmt->get_result();
$student = $student_result->fetch_assoc();
$student_id = $student['student_id'];

// Handle course cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_course_id'])) {
    $course_id = $_POST['cancel_course_id'];
    $cancel_course_sql = "DELETE FROM student_courses WHERE student_id = ? AND course_id = ? AND status = 'registered'";
    $stmt = $conn->prepare($cancel_course_sql);
    $stmt->bind_param("ii", $student_id, $course_id);
    $stmt->execute();

    // Redirect back to the billing page
    header("Location: billing.php");
    exit();
}

// Fetch registered (not yet enrolled) courses and calculate total amount
$registered_courses_sql = "
    SELECT courses.course_id, 
           courses.course_name, 
           courses.credits, 
           courses.course_fee 
    FROM student_courses 
    JOIN courses ON student_courses.course_id = courses.course_id 
    WHERE student_courses.student_id = ? AND student_courses.status = 'registered'
";
$stmt = $conn->prepare($registered_courses_sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$registered_courses_result = $stmt->get_result();

$total_amount = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Billing</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Credits</th>
                    <th>Course Fee</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($registered_courses_result->num_rows === 0) { ?>
                    <tr>
                        <td colspan="4">No registered courses.</td>
                    </tr>
                <?php } else { ?>
                    <?php while ($row = $registered_courses_result->fetch_assoc()) { 
                        $total_amount += $row['course_fee'];
                    ?>
                        <tr>
                            <td><?php echo $row['course_name']; ?></td>
                            <td><?php echo $row['credits']; ?></td>
                            <td><?php echo $row['course_fee']; ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="cancel_course_id" value="<?php echo $row['course_id']; ?>">
                                    <button type="submit" class="btn btn-danger">Cancel</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
        <h4 class="text-right">Total Amount: <?php echo $total_amount; ?></h4>
        <a href="registration.php" class="btn btn-secondary mt-3">Back to Registration</a>
    </div>
</body>
</html>