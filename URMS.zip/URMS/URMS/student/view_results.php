<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

$user_id = $_SESSION['id']; // Use the logged-in user's ID from the session

// Fetch the student's ID from the `students` table
$student_sql = "SELECT student_id FROM students WHERE id = ?";
$stmt = $conn->prepare($student_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student_result = $stmt->get_result();
$student = $student_result->fetch_assoc();
$student_id = $student['student_id'];

// Fetch the student's results
$result_sql = "
    SELECT courses.course_name, 
           results.grade, 
           results.semester 
    FROM results 
    JOIN courses ON results.course_id = courses.course_id 
    WHERE results.student_id = ?
";
$stmt = $conn->prepare($result_sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Results</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Your Results</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Grade</th>
                    <th>Semester</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_result->num_rows === 0) { ?>
                    <tr>
                        <td colspan="3">No results found.</td>
                    </tr>
                <?php } else { ?>
                    <?php while ($row = $result_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['course_name']; ?></td>
                            <td><?php echo $row['grade']; ?></td>
                            <td><?php echo $row['semester']; ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
        <a href="student_dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
    </div>
</body>
</html>
