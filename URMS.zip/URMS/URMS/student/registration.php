<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

$user_id = $_SESSION['id']; // Use the logged-in user's ID from the session

// Fetch the student's ID from the `students` table
$student_sql = "SELECT student_id FROM students WHERE id = ?";
$stmt = $conn->prepare($student_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student_result = $stmt->get_result();
$student = $student_result->fetch_assoc();
$student_id = $student['student_id'];

// Fetch all courses except those already taken by the student
$available_courses_sql = "
    SELECT courses.course_id, 
           courses.course_name, 
           courses.credits, 
           courses.course_fee 
    FROM courses 
    WHERE courses.course_id NOT IN (
        SELECT course_id FROM student_courses WHERE student_id = ?
    )
";
$stmt = $conn->prepare($available_courses_sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$available_courses_result = $stmt->get_result();

// Handle course registration or cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = $_POST['course_id'];
    if (isset($_POST['add'])) {
        // Add course
        $add_course_sql = "INSERT INTO student_courses (student_id, course_id, enrollment_date, progress) VALUES (?, ?, NOW(), 0)";
        $stmt = $conn->prepare($add_course_sql);
        $stmt->bind_param("ii", $student_id, $course_id);
        $stmt->execute();
    } elseif (isset($_POST['cancel'])) {
        // Cancel course
        $cancel_course_sql = "DELETE FROM student_courses WHERE student_id = ? AND course_id = ?";
        $stmt = $conn->prepare($cancel_course_sql);
        $stmt->bind_param("ii", $student_id, $course_id);
        $stmt->execute();
    }
    // Refresh the page to reflect changes
    header("Location: registration.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Available Courses</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Credits</th>
                    <th>Course Fee</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($available_courses_result->num_rows === 0) { ?>
                    <tr>
                        <td colspan="4">No available courses.</td>
                    </tr>
                <?php } else { ?>
                    <?php while ($row = $available_courses_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['course_name']; ?></td>
                            <td><?php echo $row['credits']; ?></td>
                            <td><?php echo $row['course_fee']; ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="course_id" value="<?php echo $row['course_id']; ?>">
                                    <button type="submit" name="add" class="btn btn-success">✔ Add</button>
                                </form>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="course_id" value="<?php echo $row['course_id']; ?>">
                                    <button type="submit" name="cancel" class="btn btn-danger">✖ Cancel</button>
                                </form>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
        <a href="billing.php" class="btn btn-primary mt-3">Go to Billing</a>
    </div>
</body>
</html>