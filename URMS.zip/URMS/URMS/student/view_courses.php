<?php
session_start();
if ($_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

$user_id = $_SESSION['id']; // Use the logged-in user's ID from the session

// Fetch the student's ID from the `students` table
$student_sql = "SELECT student_id FROM students WHERE id = ?";
$stmt = $conn->prepare($student_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$student_result = $stmt->get_result();
$student = $student_result->fetch_assoc();
$student_id = $student['student_id'];

// Fetch the courses the student is enrolled in
$course_sql = "
    SELECT courses.course_name, 
           courses.credits, 
           courses.course_fee, 
           student_courses.enrollment_date, 
           student_courses.progress 
    FROM student_courses 
    JOIN courses ON student_courses.course_id = courses.course_id 
    WHERE student_courses.student_id = ?
";
$stmt = $conn->prepare($course_sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$course_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Enrolled Courses</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Enrolled Courses</h2>
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Credits</th>
                    <th>Course Fee</th>
                    <th>Enrollment Date</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($course_result->num_rows === 0) { ?>
                    <tr>
                        <td colspan="5">No courses found.</td>
                    </tr>
                <?php } else { ?>
                    <?php while ($row = $course_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['course_name']; ?></td>
                            <td><?php echo $row['credits']; ?></td>
                            <td><?php echo $row['course_fee']; ?></td>
                            <td><?php echo $row['enrollment_date']; ?></td>
                            <td><?php echo $row['progress']; ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </tbody>
        </table>
        <a href="student_dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
    </div>
</body>
</html>
