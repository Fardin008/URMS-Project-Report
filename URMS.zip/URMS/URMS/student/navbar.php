<!-- filepath: c:\xampp\htdocs\URMS-main\student\navbar.php -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="student_dashboard.php">Student Portal</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="student_dashboard.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_courses.php">Enrolled Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="view_results.php">Results</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="registration.php">Registration</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="billing.php">Billing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../profile.php">Profile</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-danger" href="../logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>