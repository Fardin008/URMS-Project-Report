<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = $_POST['first_name']; // Updated to first_name
    $last_name = $_POST['last_name'];   // Added last_name
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    $role = $_POST['role'];
    $email = $_POST['email'];
    $blood_group = $_POST['blood_group'];
    $permanent_address = $_POST['permanent_address'];
    $mobile_no = $_POST['mobile_no'];

    // Insert user into the database
    $sql = "INSERT INTO users (first_name, last_name, password, role, email, blood_group, permanent_address, mobile_no) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $first_name, $last_name, $password, $role, $email, $blood_group, $permanent_address, $mobile_no);

    if ($stmt->execute()) {
        header('Location: manage_users.php');
        exit();
    } else {
        echo "Error adding user.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Add User</h2> <!-- Centered Title -->
        <form method="POST">
            <div class="form-group">
                <label for="first_name">First Name</label> <!-- Updated field -->
                <input type="text" name="first_name" id="first_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name</label> <!-- Added field -->
                <input type="text" name="last_name" id="last_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="role">Role</label>
                <select name="role" id="role" class="form-control" required>
                    <option value="admin">Admin</option>
                    <option value="user">User</option>
                </select>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="blood_group">Blood Group</label>
                <input type="text" name="blood_group" id="blood_group" class="form-control">
            </div>
            <div class="form-group">
                <label for="permanent_address">Permanent Address</label>
                <input type="text" name="permanent_address" id="permanent_address" class="form-control">
            </div>
            <div class="form-group">
                <label for="mobile_no">Mobile Number</label>
                <input type="text" name="mobile_no" id="mobile_no" class="form-control">
            </div>
            <button type="submit" class="btn btn-success">Add User</button>
            <a href="manage_users.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>