<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (isset($_GET['id'])) { // Use 'id' as the parameter name
    $user_id = $_GET['id']; // Correctly assign the parameter to $user_id

    // Delete user
    $sql = "DELETE FROM users WHERE id = ?"; // Use 'id' as the column name
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id); // Bind $user_id, not $id

    if ($stmt->execute()) {
        header('Location: manage_users.php');
        exit();
    } else {
        echo "Error deleting user.";
    }
} else {
    header('Location: manage_users.php');
    exit();
}
?>