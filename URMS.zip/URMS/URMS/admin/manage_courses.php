<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

// Fetch courses with faculty names from the database
$courses_sql = "
    SELECT 
        courses.course_id, 
        courses.course_name, 
        courses.credits, 
        courses.course_fee, 
        CONCAT(users.first_name, ' ', users.last_name) AS faculty_name
    FROM 
        courses
    LEFT JOIN faculty ON courses.faculty_id = faculty.faculty_id
    LEFT JOIN users ON faculty.id = users.id
";
$courses_result = $conn->query($courses_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Courses</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2 class="text-center">Manage Courses</h2> <!-- Centered Title -->
        <table class="table table-bordered text-center"> <!-- Centered Table -->
            <thead class="thead-light">
                <tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Credits</th>
                    <th>Course Fee</th>
                    <th>Faculty Name</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $courses_result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['course_id']; ?></td>
                    <td><?php echo $row['course_name']; ?></td>
                    <td><?php echo $row['credits']; ?></td>
                    <td><?php echo $row['course_fee']; ?></td>
                    <td><?php echo $row['faculty_name']; ?></td> <!-- Display faculty name -->
                    <td>
                        <a href="edit_course.php?course_id=<?php echo $row['course_id']; ?>" class="btn btn-warning">Edit</a>
                        <a href="delete_course.php?course_id=<?php echo $row['course_id']; ?>" 
                           class="btn btn-danger" 
                           onclick="return confirm('Are you sure you want to delete this course?');">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>
