<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-3">
        <h1 class="text-center">Admin Dashboard</h1> <!-- Title before navbar -->
    </div>
    <?php include 'navbar.php'; ?> <!-- Include the navigation bar -->

    <div class="container mt-5">
        <h2>Welcome to the Admin Dashboard</h2>
        <p>You can manage users, courses, and other administrative tasks from here.</p>  
    </div>
</body>
</html>
