<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];

    // Fetch course details
    $sql = "SELECT * FROM courses WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $course = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $course_name = $_POST['course_name'];
        $credits = $_POST['credits'];
        $course_fee = $_POST['course_fee'];
        $faculty_id = $_POST['faculty_id'];

        // Update course details
        $update_sql = "UPDATE courses SET course_name = ?, credits = ?, course_fee = ?, faculty_id = ? WHERE course_id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("siiii", $course_name, $credits, $course_fee, $faculty_id, $course_id);

        if ($update_stmt->execute()) {
            header('Location: manage_courses.php');
            exit();
        } else {
            echo "Error updating course.";
        }
    }
} else {
    header('Location: manage_courses.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h2>Edit Course</h2>
        <form method="POST">
            <div class="form-group">
                <label for="course_name">Course Name</label>
                <input type="text" name="course_name" id="course_name" class="form-control" value="<?php echo htmlspecialchars($course['course_name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="credits">Credits</label>
                <input type="number" name="credits" id="credits" class="form-control" value="<?php echo htmlspecialchars($course['credits']); ?>" required>
            </div>
            <div class="form-group">
                <label for="course_fee">Course Fee</label>
                <input type="number" name="course_fee" id="course_fee" class="form-control" value="<?php echo htmlspecialchars($course['course_fee']); ?>" required>
            </div>
            <div class="form-group">
                <label for="faculty_id">Faculty ID</label>
                <input type="number" name="faculty_id" id="faculty_id" class="form-control" value="<?php echo htmlspecialchars($course['faculty_id']); ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update</button>
            <a href="manage_courses.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>