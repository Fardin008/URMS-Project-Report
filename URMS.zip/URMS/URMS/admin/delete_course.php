
// filepath: c:\xampp\htdocs\URMS-main\admin\delete_course.php
<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

require '../db_connect.php';

if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];

    // Delete course
    $sql = "DELETE FROM courses WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $course_id);

    if ($stmt->execute()) {
        header('Location: manage_courses.php');
        exit();
    } else {
        echo "Error deleting course.";
    }
} else {
    header('Location: manage_courses.php');
    exit();
}
?>