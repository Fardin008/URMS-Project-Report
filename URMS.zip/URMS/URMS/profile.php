<?php
// Include database connection
require 'db_connect.php';

// Function to fetch and display user profile based on user_id
function showUserProfile($user_id) {
    global $conn;

    // Query to fetch user information from the users table based on user_id
    $user_query = "SELECT * FROM users WHERE id = ?";
    $stmt = $conn->prepare($user_query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user_result = $stmt->get_result();

    if ($user_result->num_rows > 0) {
        $user = $user_result->fetch_assoc();
        echo "<div class='card shadow-lg'>";
        echo "<div class='card-header bg-primary text-white'><h2>User Profile</h2></div>";
        echo "<div class='card-body'>";
        echo "<p><strong>Name:</strong> " . htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) . "</p>";
        echo "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
        echo "<p><strong>Blood Group:</strong> " . htmlspecialchars($user['blood_group']) . "</p>";
        echo "<p><strong>Permanent Address:</strong> " . htmlspecialchars($user['permanent_address']) . "</p>";
        echo "<p><strong>Mobile Number:</strong> " . htmlspecialchars($user['mobile_no']) . "</p>";
        echo "</div>";
        echo "</div>";
    } else {
        echo "<div class='alert alert-danger'>User not found!</div>";
    }
}

// Start session to get user_id of logged-in user
session_start();
$user_id = $_SESSION['id']; // Assuming the user_id is stored in the session after login

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <?php showUserProfile($user_id); ?>
    </div>
</body>
</html>
